author 'VisionAC - Development Team'
description 'VisionAC, provided by SCYTE.ro'
fx_version 'cerulean'
game 'gta5'

ui_page "html/index.html"

files {
    "html/*.html",
    "html/*.js",
    "html/*.css"
}

server_script 'server.lua'
client_script 'client.lua'
